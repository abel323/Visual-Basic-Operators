﻿Public Class Form1
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim firstNumber, secondNumber, result As Double
        firstNumber = CDbl(txtNum1.Text)
        secondNumber = CDbl(txtNum2.Text)
        If radAddition.Checked Then
            result = firstNumber + secondNumber
            txtResult.Text = result
        ElseIf radSubtraction.Checked Then
            result = firstNumber - secondNumber
            txtResult.Text = result
        ElseIf radMultiply.Checked Then
            result = firstNumber * secondNumber
            txtResult.Text = result
        ElseIf radDivide.Checked Then
            result = firstNumber / secondNumber
            txtResult.Text = result
        ElseIf radMod.Checked Then
            result = firstNumber Mod secondNumber
            txtResult.Text = result
        ElseIf radIntDiv.Checked Then
            result = firstNumber \ secondNumber
        End If
    End Sub
End Class
